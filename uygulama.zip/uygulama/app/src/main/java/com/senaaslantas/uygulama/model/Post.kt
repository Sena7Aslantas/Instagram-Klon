package com.senaaslantas.uygulama.model

import com.google.firebase.auth.ActionCodeUrl

data class Post(val email:String,val comment:String,val dowloandUrl:String){
}